define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var Dirent = Backbone.Model.extend({});

    return Dirent;
});
