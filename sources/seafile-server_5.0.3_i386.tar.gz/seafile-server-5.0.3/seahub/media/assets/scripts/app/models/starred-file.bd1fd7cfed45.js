define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var StarredFile = Backbone.Model.extend({});

    return StarredFile;
});
