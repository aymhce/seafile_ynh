#!/usr/bin/python
# EASY-INSTALL-SCRIPT: 'Django==1.5.12','django-admin.py'
__requires__ = 'Django==1.5.12'
import pkg_resources
pkg_resources.run_script('Django==1.5.12', 'django-admin.py')
